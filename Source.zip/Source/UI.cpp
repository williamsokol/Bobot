#include "UI.h"

using namespace BWAPI;
using namespace Filter;


using namespace BWEM;
using namespace BWEM::BWAPI_ext;
//using namespace BWEM::utils;
namespace { auto& theMap = BWEM::Map::Instance(); }

void UI::Display() 
{
    try
    {
        //BWEM::utils::gridMapExample(theMap);
        BWEM::utils::drawMap(theMap);

        // Display the game frame rate as text in the upper left area of the screen
        Broodwar->drawTextScreen(200, 0, "FPS: %d", Broodwar->getFPS());
        Broodwar->drawTextScreen(200, 20, "Average FPS: %f", Broodwar->getAverageFPS());

        // ...
    }
    catch (const std::exception& e)
    {
        Broodwar << "EXCEPTION: " << e.what() << std::endl;
    }
    // Called once every game frame

    // Display the game frame rate as text in the upper left area of the screen
    int seconds = Broodwar->getFrameCount() / 24;
    int minutes = seconds / 60;
    seconds %= 60;
    Broodwar->drawTextScreen(20, 20, "time %.2d:%.2d", minutes, seconds);
    for (int i = 0; i < bot->unitQueue.size(); i++)
    {
        Broodwar->drawTextScreen(20, i * 10 + 60, "will make: %s onit? %s",
            bot->unitQueue[i].unit.c_str(),
            bot->unitQueue[i].builder != NULL ? "true" : "false");
    }
    Broodwar->drawTextScreen(200, 0, "FPS: %d", Broodwar->getFPS());
    Broodwar->drawTextScreen(200, 20, "Average FPS: %f", Broodwar->getAverageFPS());

    if (bot->ref.refinery) {
        int i = 0;
        for (Unit w : bot->ref.refWorkers)
        {
            Broodwar->drawTextMap(w->getPosition(), "%c Invis %d", Text::Yellow, i);

            i++;
        }
    }
}